Gaslightning Staking Program (Anchor) - ZIP package
--------------------------------------------------
This package contains a reference Anchor program implementing an on-chain staking pool
with a fixed 10% APR reward distribution model (centralized admin-owned staking & reward wallets).

Important: This code is provided as-is. Do NOT deploy on mainnet without thorough testing and a security audit.

Included files:
- Anchor.toml
- Cargo.toml
- programs/gaslightning-staking/src/lib.rs
- scripts/deploy_devnet.sh (helper script to build & deploy on devnet)

Defaults used in this package:
- Token name: Gaslightning ($GAS)
- Reward model: Fixed 10% APR (annual percentage rate)
- Lock duration: none (users can request withdraws; admin must execute withdrawals)
- Staking/admin wallet: 7t6Z6dDThNy7cHL2z2wE1xD2g4wBd5VY79qngp2s99HZ (admin-owned ATA)
