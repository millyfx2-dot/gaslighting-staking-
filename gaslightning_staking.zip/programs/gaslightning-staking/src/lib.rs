use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer};
declare_id!("Fg6PaFpoGXkYsidMpWFKuY2kM4qk1Xq7u6n9u6ZrY3k9"); // replace after deployment

// Admin staking wallet you provided (admin-owned token accounts)
// Staking wallet & reward wallet ATAs should be created and provided at init
// Admin address (wallet owner) is the signer for admin-only functions.

#[program]
pub mod gaslightning_staking {
    use super::*;

    // Initialize pool:
    // reward_apr_bps: basis points (1000 = 10.00% APR)
    pub fn initialize(
        ctx: Context<Initialize>,
        reward_apr_bps: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.pool;
        pool.authority = ctx.accounts.authority.key();
        pool.stake_mint = ctx.accounts.stake_mint.key();
        pool.reward_mint = ctx.accounts.reward_mint.key();
        pool.staking_wallet = ctx.accounts.staking_wallet.key();
        pool.reward_wallet = ctx.accounts.reward_wallet.key();
        pool.total_staked = 0;
        pool.reward_apr_bps = reward_apr_bps;
        pool.last_update_timestamp = Clock::get()?.unix_timestamp as u64;
        pool.reward_per_token_stored = 0;
        Ok(())
    }

    // Users call stake -> transfers from user ATA -> admin staking wallet (user signs)
    pub fn stake(ctx: Context<Stake>, amount: u64) -> Result<()> {
        require!(amount > 0, StakingError::InvalidAmount);
        update_pool(&mut ctx.accounts.pool)?;
        update_user_on_stake(&mut ctx.accounts.user, &ctx.accounts.pool)?;

        let cpi_accounts = Transfer {
            from: ctx.accounts.from.to_account_info(),
            to: ctx.accounts.staking_wallet.to_account_info(),
            authority: ctx.accounts.user_signer.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, amount)?;

        ctx.accounts.pool.total_staked = ctx.accounts.pool.total_staked.checked_add(amount).ok_or(StakingError::Overflow)?;
        ctx.accounts.user.staked_amount = ctx.accounts.user.staked_amount.checked_add(amount).ok_or(StakingError::Overflow)?;
        ctx.accounts.user.reward_per_token_paid = ctx.accounts.pool.reward_per_token_stored;
        Ok(())
    }

    // Admin withdraws tokens back to user (admin must sign)
    pub fn withdraw_for_user(ctx: Context<WithdrawForUser>, amount: u64) -> Result<()> {
        require!(amount > 0, StakingError::InvalidAmount);
        let user = &mut ctx.accounts.user;
        require!(user.staked_amount >= amount, StakingError::InsufficientStaked);

        update_pool(&mut ctx.accounts.pool)?;
        update_user_on_stake(user, &ctx.accounts.pool)?;

        user.staked_amount = user.staked_amount.checked_sub(amount).ok_or(StakingError::Overflow)?;
        ctx.accounts.pool.total_staked = ctx.accounts.pool.total_staked.checked_sub(amount).ok_or(StakingError::Overflow)?;

        let cpi_accounts = Transfer {
            from: ctx.accounts.staking_wallet.to_account_info(),
            to: ctx.accounts.to.to_account_info(),
            authority: ctx.accounts.admin.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, amount)?;
        user.reward_per_token_paid = ctx.accounts.pool.reward_per_token_stored;
        Ok(())
    }

    // Admin distributes rewards to a user (admin must sign)
    pub fn distribute_rewards(ctx: Context<DistributeRewards>) -> Result<()> {
        update_pool(&mut ctx.accounts.pool)?;
        update_user_on_stake(&mut ctx.accounts.user, &ctx.accounts.pool)?;
        let user = &mut ctx.accounts.user;
        let reward = user.rewards;
        if reward == 0 { return Ok(()); }
        user.rewards = 0;
        user.reward_per_token_paid = ctx.accounts.pool.reward_per_token_stored;

        let cpi_accounts = Transfer {
            from: ctx.accounts.reward_wallet.to_account_info(),
            to: ctx.accounts.to.to_account_info(),
            authority: ctx.accounts.admin.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, reward)?;
        Ok(())
    }

    // Admin funds reward wallet (transfer into reward wallet ATA)
    pub fn fund_rewards(ctx: Context<FundRewards>, amount: u64) -> Result<()> {
        let cpi_accounts = Transfer {
            from: ctx.accounts.from.to_account_info(),
            to: ctx.accounts.reward_wallet.to_account_info(),
            authority: ctx.accounts.admin.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, amount)?;
        Ok(())
    }

    pub fn set_reward_apr(ctx: Context<SetRewardAPR>, apr_bps: u64) -> Result<()> {
        update_pool(&mut ctx.accounts.pool)?;
        ctx.accounts.pool.reward_apr_bps = apr_bps;
        Ok(())
    }
}

// Helper functions: compute rewards based on 10% APR stored in pool.reward_apr_bps
fn update_pool(pool: &mut Account<Pool>) -> Result<()> {
    let now = Clock::get()?.unix_timestamp as u64;
    let seconds_per_year: u128 = 31536000u128;
    if pool.total_staked == 0 {
        pool.last_update_timestamp = now;
        return Ok(());
    }
    let elapsed = now.checked_sub(pool.last_update_timestamp).ok_or(StakingError::Overflow)?;
    if elapsed == 0 { return Ok(()); }

    // reward = total_staked * APR_bps / 10000 * elapsed / seconds_per_year
    // Use u128 for precision: reward_scaled = total_staked * apr_bps * elapsed
    let total_staked_128 = pool.total_staked as u128;
    let apr_bps_128 = pool.reward_apr_bps as u128;
    let elapsed_128 = elapsed as u128;

    let reward_scaled = total_staked_128
        .checked_mul(apr_bps_128).ok_or(StakingError::Overflow)?
        .checked_mul(elapsed_128).ok_or(StakingError::Overflow)?;

    // divide by (10000 * seconds_per_year)
    let denom = 10000u128.checked_mul(seconds_per_year).ok_or(StakingError::Overflow)?;
    let reward = reward_scaled.checked_div(denom).ok_or(StakingError::Overflow)?;

    // reward per token stored increment = reward * 1e18 / total_staked
    let reward_scaled2 = (reward as u128).checked_mul(1_000_000_000_000_000_000u128).ok_or(StakingError::Overflow)?;
    let increment = reward_scaled2.checked_div(total_staked_128).ok_or(StakingError::Overflow)?;
    pool.reward_per_token_stored = pool.reward_per_token_stored.checked_add(increment).ok_or(StakingError::Overflow)?;
    pool.last_update_timestamp = now;
    Ok(())
}

fn update_user_on_stake(user: &mut Account<User>, pool: &Account<Pool>) -> Result<()> {
    let rpt_diff = pool.reward_per_token_stored.checked_sub(user.reward_per_token_paid).ok_or(StakingError::Overflow)?;
    if rpt_diff == 0 { return Ok(()); }
    let earned = (user.staked_amount as u128).checked_mul(rpt_diff).ok_or(StakingError::Overflow)?;
    let earned = earned.checked_div(1_000_000_000_000_000_000u128).ok_or(StakingError::Overflow)?;
    user.rewards = user.rewards.checked_add(earned as u64).ok_or(StakingError::Overflow)?;
    Ok(())
}

#[account]
pub struct Pool {
    pub authority: Pubkey,
    pub stake_mint: Pubkey,
    pub reward_mint: Pubkey,
    pub staking_wallet: Pubkey,
    pub reward_wallet: Pubkey,
    pub total_staked: u64,
    pub reward_apr_bps: u64, // APR in basis points (1000 = 10.00%)
    pub last_update_timestamp: u64,
    pub reward_per_token_stored: u128,
}

#[account]
pub struct User {
    pub owner: Pubkey,
    pub staked_amount: u64,
    pub rewards: u64,
    pub reward_per_token_paid: u128,
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,

    #[account(init, payer = authority, space = 8 + std::mem::size_of::<Pool>())]
    pub pool: Account<'info, Pool>,

    pub stake_mint: Account<'info, Mint>,
    pub reward_mint: Account<'info, Mint>,

    #[account(mut)]
    pub staking_wallet: Account<'info, TokenAccount>,

    #[account(mut)]
    pub reward_wallet: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Stake<'info> {
    #[account(mut, signer)]
    pub user_signer: AccountInfo<'info>,
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,

    #[account(mut)]
    pub pool: Account<'info, Pool>,

    #[account(init_if_needed, payer = user_signer, space = 8 + std::mem::size_of::<User>(), seeds = [b"user", user_signer.key().as_ref(), pool.key().as_ref()], bump)]
    pub user: Account<'info, User>,

    #[account(mut)]
    pub staking_wallet: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct WithdrawForUser<'info> {
    #[account(mut, signer)]
    pub admin: AccountInfo<'info>,
    #[account(mut)]
    pub staking_wallet: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
    #[account(mut, has_one = owner, seeds = [b"user", to.owner.as_ref(), pool.key().as_ref()], bump)]
    pub user: Account<'info, User>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct DistributeRewards<'info> {
    #[account(mut, signer)]
    pub admin: AccountInfo<'info>,
    #[account(mut)]
    pub reward_wallet: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
    #[account(mut, has_one = owner, seeds = [b"user", to.owner.as_ref(), pool.key().as_ref()], bump)]
    pub user: Account<'info, User>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct FundRewards<'info> {
    #[account(mut, signer)]
    pub admin: AccountInfo<'info>,
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    #[account(mut)]
    pub reward_wallet: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct SetRewardAPR<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
}

#[error_code]
pub enum StakingError {
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Insufficient staked amount")]
    InsufficientStaked,
    #[msg("Math overflow")]
    Overflow,
}
