#!/bin/bash
set -e
echo "Setting Solana to devnet..."
solana config set --url https://api.devnet.solana.com
echo "Generating keypair (if you already have one, skip this and set SOLANA_KEY environment)..."
if [ ! -f ~/.config/solana/id.json ]; then
  solana-keygen new --outfile ~/.config/solana/id.json
fi
solana airdrop 2 || true
echo "Building Anchor program..."
anchor build
echo "Deploying Anchor program (anchor deploy)..."
anchor deploy
echo "Deployed. Check the Program Id printed above."
